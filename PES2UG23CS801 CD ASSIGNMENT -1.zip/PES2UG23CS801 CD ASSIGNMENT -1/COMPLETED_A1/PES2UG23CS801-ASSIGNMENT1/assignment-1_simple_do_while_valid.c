#include <stdio.h>

int main()
{
	int a,b=6; // initialization within declaration
	int x[2][3][4];
	int arr[5] = { 10, 20, 30, 40, 50 };
	a = 5 + 3;
	do {a = 5;} while (a<1); // do while loop
	
}

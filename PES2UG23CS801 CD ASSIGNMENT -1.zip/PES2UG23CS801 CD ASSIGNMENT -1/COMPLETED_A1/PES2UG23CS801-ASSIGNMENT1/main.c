#include <stdio.h>
#include <stdlib.h>
#include "symbol_table.h"
#include "parser.tab.h"

extern FILE* yyin;
extern int yyparse();
extern SymbolTable* symbol_table;

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE* input = fopen(argv[1], "r");
    if (!input) {
        printf("Cannot open input file %s\n", argv[1]);
        return 1;
    }

    yyin = input;
    symbol_table = create_symbol_table();
    if (!symbol_table) {
        printf("Failed to create symbol table\n");
        fclose(input);
        return 1;
    }

    printf("Starting parse...\n");
    int result = yyparse();

    if (result == 0) {
        printf("Parsing completed successfully.\n");
        print_symbol_table(symbol_table);
    } else {
        printf("Parsing failed.\n");
    }

    destroy_symbol_table(symbol_table);
    fclose(input);
    return result;
}
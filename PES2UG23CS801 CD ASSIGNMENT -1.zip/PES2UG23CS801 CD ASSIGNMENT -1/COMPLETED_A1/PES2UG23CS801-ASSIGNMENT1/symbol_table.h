#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAME 31
#define MAX_SCOPE 100
#define MAX_DIMENSIONS 3

typedef struct {
    char name[MAX_NAME + 1];
    char type[20];          // "int", "char", "float", "double", "void", "array"
    int scope;
    int line_declared;
    int *lines_used;
    int num_uses;
    int is_array;
    int dimensions[MAX_DIMENSIONS];
    int num_dimensions;
    int is_initialized;      // Track if variable is initialized
    union {
        int int_val;
        float float_val;
        char char_val;
        double double_val;
    } value;
} Symbol;

typedef struct {
    Symbol *symbols;
    int count;
    int capacity;
    int current_scope;
} SymbolTable;

// Function declarations
SymbolTable* create_symbol_table();
void destroy_symbol_table(SymbolTable *table);
int insert_symbol(SymbolTable *table, const char *name, const char *type, int line);
int lookup_symbol(SymbolTable *table, const char *name, int scope);
void enter_scope(SymbolTable *table);
void exit_scope(SymbolTable *table);
void print_symbol_table(SymbolTable *table);
void add_line_use(SymbolTable *table, const char *name, int line);
int mark_initialized(SymbolTable *table, const char *name);
int is_initialized(SymbolTable *table, const char *name);
void set_array_dimensions(SymbolTable *table, const char *name, int dimensions[], int num_dimensions);

#endif
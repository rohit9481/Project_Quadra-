package com.truebank.controller;

import org.springframework.stereotype.Controller;

@Controller
public class RootController {
    // Empty controller - all methods removed to avoid conflicts
} 
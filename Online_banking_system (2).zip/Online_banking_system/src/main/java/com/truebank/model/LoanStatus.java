package com.truebank.model;

public enum LoanStatus {
    PENDING,
    APPROVED,
    REJECTED,
    DISBURSED,
    CLOSED
}

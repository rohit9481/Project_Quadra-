package com.truebank.model;

public enum LoanType {
    HOME_LOAN,
    PERSONAL_LOAN,
    EDUCATION_LOAN,
    VEHICLE_LOAN,
    BUSINESS_LOAN
}

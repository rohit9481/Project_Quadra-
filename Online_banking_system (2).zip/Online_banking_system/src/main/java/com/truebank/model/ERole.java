package com.truebank.model;

public enum ERole {
    ROLE_USER,    // Regular bank customer
    ROLE_MANAGER, // Branch manager
    ROLE_BANKER   // Bank administrator
}

package com.truebank.model;

public enum AccountType {
    SAVINGS,
    CURRENT,
    FIXED_DEPOSIT
}

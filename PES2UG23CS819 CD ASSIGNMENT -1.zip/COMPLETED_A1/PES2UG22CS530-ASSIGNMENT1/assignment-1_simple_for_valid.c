

int main()
{
	int a,b=6;
	char c[5]; // array declaration
	a = 5 + 3;
	b = ++a; // unary op
	for(i = 0;i<5;++i) // for loop
	{
		c[i] = i; //assignment to array position
	}
}

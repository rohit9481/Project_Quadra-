#include "symbol_table.h"

SymbolTable* create_symbol_table() {
    SymbolTable *table = (SymbolTable*)malloc(sizeof(SymbolTable));
    if (!table) return NULL;
    
    table->capacity = 100;
    table->count = 0;
    table->current_scope = 0;
    table->symbols = (Symbol*)malloc(table->capacity * sizeof(Symbol));
    
    if (!table->symbols) {
        free(table);
        return NULL;
    }

    // Initialize memory
    memset(table->symbols, 0, table->capacity * sizeof(Symbol));
    return table;
}

void destroy_symbol_table(SymbolTable *table) {
    if (!table) return;
    
    for (int i = 0; i < table->count; i++) {
        if (table->symbols[i].lines_used) {
            free(table->symbols[i].lines_used);
        }
    }
    free(table->symbols);
    free(table);
}

int insert_symbol(SymbolTable *table, const char *name, const char *type, int line) {
    if (!table || !name || !type) return 0;

    // Check if symbol already exists in current scope
    for (int i = 0; i < table->count; i++) {
        if (table->symbols[i].scope == table->current_scope &&
            strcmp(table->symbols[i].name, name) == 0) {
            return 0; // Symbol already exists in current scope
        }
    }

    // Expand capacity if needed
    if (table->count >= table->capacity) {
        int new_capacity = table->capacity * 2;
        Symbol *new_symbols = realloc(table->symbols, new_capacity * sizeof(Symbol));
        if (!new_symbols) return 0;
        
        table->symbols = new_symbols;
        table->capacity = new_capacity;
    }

    Symbol *sym = &table->symbols[table->count];
    strncpy(sym->name, name, MAX_NAME);
    sym->name[MAX_NAME] = '\0';
    strncpy(sym->type, type, sizeof(sym->type) - 1);
    sym->type[sizeof(sym->type) - 1] = '\0';
    
    sym->scope = table->current_scope;
    sym->line_declared = line;
    sym->lines_used = malloc(sizeof(int));
    sym->num_uses = 0;
    sym->is_array = 0;
    sym->num_dimensions = 0;
    sym->is_initialized = 0;
    memset(sym->dimensions, 0, sizeof(sym->dimensions));

    table->count++;
    return 1;
}

void add_line_use(SymbolTable *table, const char *name, int line) {
    if (!table || !name) return;

    int idx = lookup_symbol(table, name, table->current_scope);
    if (idx == -1) {
        // Check if the symbol exists in any outer scope
        for (int scope = table->current_scope - 1; scope >= 0; scope--) {
            idx = lookup_symbol(table, name, scope);
            if (idx != -1) break;
        }
        if (idx == -1) return; // Symbol not found in any accessible scope
    }

    Symbol *sym = &table->symbols[idx];
    sym->lines_used = realloc(sym->lines_used, (sym->num_uses + 1) * sizeof(int));
    if (sym->lines_used) {
        sym->lines_used[sym->num_uses++] = line;
    }
}

int lookup_symbol(SymbolTable *table, const char *name, int scope) {
    if (!table || !name) return -1;

    // Search from current scope down to global scope
    for (int s = scope; s >= 0; s--) {
        for (int i = 0; i < table->count; i++) {
            if (table->symbols[i].scope == s && 
                strcmp(table->symbols[i].name, name) == 0) {
                return i;
            }
        }
    }
    return -1;
}

void enter_scope(SymbolTable *table) {
    if (table) {
        table->current_scope++;
    }
}

void exit_scope(SymbolTable *table) {
    if (table && table->current_scope > 0) {
        table->current_scope--;
    }
}

int mark_initialized(SymbolTable *table, const char *name) {
    if (!table || !name) return 0;
    
    int idx = lookup_symbol(table, name, table->current_scope);
    if (idx != -1) {
        table->symbols[idx].is_initialized = 1;
        return 1;
    }
    return 0;
}

int is_initialized(SymbolTable *table, const char *name) {
    if (!table || !name) return 0;
    
    int idx = lookup_symbol(table, name, table->current_scope);
    if (idx != -1) {
        return table->symbols[idx].is_initialized;
    }
    return 0;
}

void set_array_dimensions(SymbolTable *table, const char *name, int dimensions[], int num_dimensions) {
    if (!table || !name || !dimensions || num_dimensions > MAX_DIMENSIONS) return;
    
    int idx = lookup_symbol(table, name, table->current_scope);
    if (idx != -1) {
        Symbol *sym = &table->symbols[idx];
        sym->is_array = 1;
        sym->num_dimensions = num_dimensions;
        for (int i = 0; i < num_dimensions; i++) {
            sym->dimensions[i] = dimensions[i];
        }
    }
}

void print_symbol_table(SymbolTable *table) {
    if (!table) return;

    printf("\nSymbol Table:\n");
    printf("%-20s %-10s %-8s %-8s %-8s %-15s\n", 
           "Name", "Type", "Scope", "Line", "Array", "Uses");
    printf("----------------------------------------------------------\n");
    
    for (int i = 0; i < table->count; i++) {
        Symbol *sym = &table->symbols[i];
        printf("%-20s %-10s %-8d %-8d %-8s ", 
               sym->name, sym->type, sym->scope, sym->line_declared,
               sym->is_array ? "Yes" : "No");
        
        // Print array dimensions if applicable
        if (sym->is_array && sym->num_dimensions > 0) {
            printf("[");
            for (int d = 0; d < sym->num_dimensions; d++) {
                printf("%d", sym->dimensions[d]);
                if (d < sym->num_dimensions - 1) printf("][");
            }
            printf("] ");
        }

        // Print line uses
        for (int j = 0; j < sym->num_uses; j++) {
            printf("%d ", sym->lines_used[j]);
        }
        printf("\n");
    }
}